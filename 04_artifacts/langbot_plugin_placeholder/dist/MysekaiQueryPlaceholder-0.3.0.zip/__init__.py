"""MysekaiQueryPlaceholder plugin package."""
