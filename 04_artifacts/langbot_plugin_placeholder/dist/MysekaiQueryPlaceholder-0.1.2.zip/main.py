"""Placeholder plugin for LangBot upload smoke test."""

from langbot_plugin.api.definition.plugin import APIHost, BasePlugin


class MysekaiQueryPlaceholder(BasePlugin):
    """Minimal plugin class for runtime mount/initialize validation."""

    def __init__(self, host: APIHost):
        super().__init__(host)

    async def initialize(self):
        """Called by plugin runtime during async initialization."""
        return
