# MysekaiQueryPlaceholder

This is a minimal placeholder plugin package for LangBot WebUI upload/install/initialize smoke testing.

It does not register any command handlers yet.
